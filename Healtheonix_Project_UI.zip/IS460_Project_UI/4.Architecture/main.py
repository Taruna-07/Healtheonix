from tkinter import Tk, Label, Frame, Button, Text
from flask import Flask

app4 = Flask(__name__)

# Define colors
BG_COLOR = "#666666"
ACCENT_COLOR = "#000000"
TEXT_COLOR = "#FFFFFF"

# Create main window
root = Tk()
root.title("Architecture - Scalability & Accessibility")
root.geometry("800x500")
root.configure(bg=BG_COLOR)

# Create header frame
header_frame = Frame(root, bg=ACCENT_COLOR, height=50)
header_frame.pack(fill="x")

# Create title label
title_label = Label(header_frame, text="Architecture Overview", font=("Arial", 18, "bold"), bg=ACCENT_COLOR, fg=TEXT_COLOR)
title_label.pack(pady=10)

# Create sub-frames for scalability and accessibility
scalability_frame = Frame(root, bg=BG_COLOR, borderwidth=1, relief="groove")
scalability_frame.pack(fill="both", padx=10, pady=10)

accessibility_frame = Frame(root, bg=BG_COLOR, borderwidth=1, relief="groove")
accessibility_frame.pack(fill="both", padx=10, pady=10)

# Create labels and text boxes for scalability
scalability_label = Label(scalability_frame, text="Scalable Framework", font=("Arial", 16, "bold"), bg=BG_COLOR, fg=ACCENT_COLOR)
scalability_label.pack(pady=5)

scalability_text = Text(scalability_frame, wrap="word", height=5, bg=BG_COLOR, fg=TEXT_COLOR)
scalability_text.insert("end", "Cloud-based architecture for unlimited scalability.\nHandles dynamic healthcare data and communication needs.\nEnsures efficient resource allocation and performance.")
scalability_text.configure(state="disabled")
scalability_text.pack(pady=5)

# Create labels and text boxes for accessibility
accessibility_label = Label(accessibility_frame, text="Accessibility Across Healthcare Facilities", font=("Arial", 16, "bold"), bg=BG_COLOR, fg=ACCENT_COLOR)
accessibility_label.pack(pady=5)

accessibility_text = Text(accessibility_frame, wrap="word", height=5, bg=BG_COLOR, fg=TEXT_COLOR)
accessibility_text.insert("end", "Provides secure access to authorized users across multiple healthcare facilities.\nEnsures smooth performance during system expansion and integration with existing infrastructure.\nSupports data sharing and collaboration between healthcare providers.")
accessibility_text.configure(state="disabled")
accessibility_text.pack(pady=5)

# Create button frame
button_frame = Frame(root, bg=BG_COLOR)
button_frame.pack(fill="x", side="bottom")

# Create button for more information
learn_more_button = Button(button_frame, text="Learn More about Architecture", bg=ACCENT_COLOR, fg=TEXT_COLOR)
learn_more_button.pack(pady=10)

# Start the main event loop
root.mainloop()
