from tkinter import Tk, Label, Frame, Button, Text, Checkbutton
from flask import Flask

app5 = Flask(__name__)

# Define colors
BG_COLOR = "#666666"
ACCENT_COLOR = "#000000"
TEXT_COLOR = "#FFFFFF"

# Create main window
root = Tk()
root.title("Security - Encryption and Authentication")
root.geometry("800x500")
root.configure(bg=BG_COLOR)

# Create header frame
header_frame = Frame(root, bg=ACCENT_COLOR, height=50)
header_frame.pack(fill="x")

# Create title label
title_label = Label(header_frame, text="Security Details", font=("Arial", 18, "bold"), bg=ACCENT_COLOR, fg=TEXT_COLOR)
title_label.pack(pady=10)

# Create section frames
encryption_frame = Frame(root, bg=BG_COLOR)
encryption_frame.pack(fill="both", expand=True)

authentication_frame = Frame(root, bg=BG_COLOR)
authentication_frame.pack(fill="both", expand=True)

# Create encryption details section
encryption_label = Label(encryption_frame, text="Encryption Techniques:", font=("Arial", 16, "bold"), bg=BG_COLOR, fg=TEXT_COLOR)
encryption_label.pack(pady=10)

encryption_text = Text(encryption_frame, bg="#f0f0f0", fg=TEXT_COLOR, width=50, height=5)
encryption_text.insert(1.0, "End-to-end encryption for all communication routes.")
encryption_text.pack(pady=10)

hipaa_checkbox = Checkbutton(encryption_frame, text="Priority on data protection and compliance with HIPAA", bg=BG_COLOR, fg=TEXT_COLOR, selectcolor=ACCENT_COLOR)
hipaa_checkbox.pack(pady=10)

# Create authentication details section
authentication_label = Label(authentication_frame, text="Authentication:", font=("Arial", 16, "bold"), bg=BG_COLOR, fg=TEXT_COLOR)
authentication_label.pack(pady=10)

authentication_text = Text(authentication_frame, bg="#f0f0f0", fg=TEXT_COLOR, width=50, height=5)
authentication_text.insert(1.0, "Strong user authentication procedures utilizing multi-factor authentication.")
authentication_text.pack(pady=10)

rbac_checkbox = Checkbutton(authentication_frame, text="Role-based access controls for enhanced information security", bg=BG_COLOR, fg=TEXT_COLOR, selectcolor=ACCENT_COLOR)
rbac_checkbox.pack(pady=10)

# Start the main event loop
root.mainloop()
